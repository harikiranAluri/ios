import UIKit

var greeting = "Hello, playground"
var hari="kiran"
print(hari + greeting)
